<html>
<head>
<link rel="stylesheet" type = "text/css" href="style/style.css">
<style>
.formcenter{ margin: auto; float: center; padding: 10px; width: 500px; font-size:large; color:#040404; background-color:#3CAEA3; input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  font-size:large;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}	} @media only screen and (min-width:900px) {.formcenter{ margin: auto; float: center; padding: 10px; width: 800px; font-size:xx-large; color:#040404; background-color:#3CAEA3;	}}
</style>
</head>
<body>
<div class="heading">Raginee Gaur Smriti Foundation</div>
<div class="topnav">
    <a class ="active" href="https://www.rgsf.org">Home</a>
    <a href="https://www.rgsf.org/programs">Support Programs</a>
    <a href="#">Self-help</a>
    <a href="#">Beneficiaries</a>
    <a href="https://www.rgsf.org/inspire">Our Inspiration</a>
    <a href="#">Contributors</a>
    <a href="#">Login</a>
</div>

<div class="heading2">Register Me!</div>
<form id="form1" class="" method="POST" action="register2">
<div class="formcenter">
		Your Name/ Organization: <br><input type="text" name="name" size ="50" placeholder = "Enter Full Name" Required><br>
		Guardian/ Representative (if, any):<br><input type="text" name="person" size ="50" placeholder = "Name of our Contact" ><br>
		Mobile Number to Contact:<br> <input type = "text" name="mobile" size ="30" placeholder ="Mobile Number (10 Digits without Special Characters)" Required><br>
		Choose Appropriate Class: <br>
		<input type="radio" name="usertype" value="11" selected>Support Seeker
		<input type="radio" name="usertype" value="12">Contributor<br>
		<input type="radio" name="usertype" value="13">Well Wisher
		<input type="radio" name="usertype" value="14">Anonymous Doner<br>
		<input type="radio" name="usertype" value="19">Others <br>
		<input type="submit" name="submit" value="submit"> 
		</div>
		</form>	
<div class="para">We value your data privacy concerns and therefore take adequate precautions towards safeguarding the personal information provided by you. The information in pieces if shared with other parties is processd with due authorization process and is only carried out when it becomes abosolute necessity and is aligned towards the cause of establishing this organization. You can change your profile settings to keep your name and identity as annonymous for added protection of the personal data.</div> 
</body>
</html>